import json
import requests
import os
import trelloAPI

json_file = '{  "$schema":"http://json-schema.org/draft-04/schema#","buildresult":"fail", "projectPath": "/home/bilmuhlab/Desktop/Group9-SQLConstraintChecker/difference1-test.sql","title": "Code versioning request","projectDescription":"Operation can be repository_creation,commit,merge,push,revert,pull",	    "destination": "6","projectName":"GtuDevOps2",	    "origin": "1",	 "result":"True",   "operation":"uploadsql","action":"uploadsql",   "github_login": "canerkarakas",    "github_password": "36bc0D02.",	    "repository_url": "https://github.com/canerkarakas/GtuDevOps"}'

#!/usr/bin/env python
# -*- coding: utf-8 -*- 
#from post.receive import planCodeAPI

def getToDoList(board):
	if( board!=None):
	 	return board.get_lists(None)[0]

def getDoingList(board):
	if( board!=None):
		return board.get_lists(None)[1]

def getBuildList(board):
	if( board!=None):
	 	return board.get_lists(None)[2]


def getTestList(board):
	if( board!=None):
		return board.get_lists(None)[3]

def getDeployList(board):
	if( board!=None):
		return board.get_lists(None)[4]

def getSQLList(board):
	if( board!=None):
		return board.get_lists(None)[2]

def moveAllCardToList(trello,listID):
	for x in trello.board.all_cards():
	 	trello.moveCard2(x.id,listID)

def moveAllCardToDOING(trello,projectName):
	moveAllCardToList(trello,getTrelloDoingList(trello,projectName).id)

def moveAllCardToTEST(trello,projectName):
	moveAllCardToList(trello,getTrelloTestList(trello,projectName).id)

def moveAllCardToDEPLOY(trello,projectName):
	moveAllCardToList(trello,getTrelloDeployList(trello,projectName).id)

def moveAllCardToBUILD(trello,projectName):
	moveAllCardToList(trello,getTrelloBuildList(trello,projectName).id)

def moveAllCardToSQL(trello,projectName):
	moveAllCardToList(trello,getTrelloSQLList(trello,projectName).id)

def deleteCard(trello,cardID):
	trello.removeCard(cardID)

def getTrelloToDoList(trello,projectName): # id name
	return getToDoList(trello.getBoardByName(projectName))


def getTrelloDoingList(trello,projectName):
	board = trello.getBoardByName(projectName)
	return getDoingList(board)

def getTrelloBuildList(trello,projectName):
	board = trello.getBoardByName(projectName)
	return getBuildList(board)

def getTrelloSQLList(trello,projectName):
	board = trello.getBoardByName(projectName)
	return getSQLList(board)

def getTrelloTestList(trello,projectName):
	board = trello.getBoardByName(projectName)
	return getTestList(board)

def getTrelloDeployList(trello,projectName):
	board = trello.getBoardByName(projectName)
	return getDeployList(board)

def splitPathAndReturnFilename(path):
        return path.split("/")[-1]

def main_function(json_file):
	json_file = json.loads(json_file)
	origin = json_file['origin']
	trello = trelloAPI.trello(apiKey="88b6dfc53416a80d41bb516cb628df38",TOKEN="fd6bfab04572f641420ef120652d1adad1037f8189157dc7e1e6649244284ae1")


	if origin == "1":
		buildresult = json_file['buildresult']
		project_name = json_file['project_name']
		if buildresult == "success":
			moveAllCardToTEST(trello,project_name)
		else :
			repository_url = json_file['repository_url']
			moveAllCardToDOING(trello,project_name)
			path = os.getcwd()
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "revert",'origin':"2",'destination':"6",'operation':"revert", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': repository_url,'repository_path':path+"/GtuDevOps/"+project_name, 'project_name': project_name})
	
	elif origin == "3":
		projectName = json_file['projectName']
		status = json_file['status']
		if status == "success":
			status2 = json_file['status2']
			if status2 == "success":
				board = trello.getBoardByName(projectName)
				boardList= trello.boardList()
				lists = board.all_lists()
				deploy = lists[4]
				trello.createCard(board.id, deploy.id,"UNDEPLOY SUCCES")
			elif status == "fail":
				boardList= trello.boardList()
				board = trello.getBoardByName(projectName)
				lists = board.all_lists()
				deploy = lists[4]
				trello.createCard(board.id, deploy.id,"UNDEPLOY FAIL")
			else :
				board = trello.getBoardByName(projectName)
				lists = board.all_lists()
				deploy = lists[4]
				trello.createCard(board.id, deploy.id,"DEPLOY SUCCESS")
		else :
			repository_url = json_file['repoUrl']
			board = trello.getBoardByName(projectName)
			lists = board.all_lists()
			deploy = lists[4]
			trello.createCard(board.id, deploy.id,"DEPLOY FAIL")
			path = os.getcwd()
			os.popen('git clone '+repository_url)
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "revert",'origin':"2",'destination':"6",'operation':"revert", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': repository_url,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName})
	
	elif origin == "4":
		projectName = json_file['projectName'].lower()
		action = json_file['action']
		if  action == "assignment":
			projectDescription = json_file['projectDescription']
			path = os.getcwd()
			os.popen('git clone https://github.com/canerkarakas/GtuDevOps.git')
			os.popen('mkdir '+path+'/'+"GtuDevOps/"+projectName)
			os.popen('touch '+path+'/'+"GtuDevOps/"+projectName+"/"+projectName+".txt")
			os.popen('git -C '+path+'/'+"GtuDevOps"+' remote set-url origin https://'+"canerkarakas"+':'+"36bc0D02."+'@github.com/'+"canerkarakas"+'/GtuDevOps.git')
			os.popen('git -C '+path+'/'+"GtuDevOps add "+projectName)
			os.popen('git -C '+path+'/GtuDevOps/'+projectName+' commit -m "first commit"')
			os.popen('git -C '+path+'/'+"GtuDevOps"+' push -f -u origin master')
			trello.createBoard(projectName)
			board = trello.getBoardByName(projectName)
			lists = board.all_lists()
			toDo = lists[0]
			trello.createCard(board.id, toDo.id,projectDescription)
			trello.createCard(board.id, toDo.id,projectName)
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "repository_creation",'origin':"2",'destination':"6",'operation':"repository_creation", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps/tree/master/"+projectName,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName})
            		#requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "repository_creation",'origin':"2",'destination':"6",'operation':"commit", 'github_login': "canerkarakas",
            #'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps/tree/master/"+projectName,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName})

		elif action == "undeploy":
			board = trello.getBoardByName(projectName)
			if board != None :
				requests.post("http://localhost:8081/", data = {'origin':"2",'destination':"3","deployment":"undeploy",'repoUrl': "https://github.com/canerkarakas/GtuDevOps.git","git_id":"canerkarakas","git_pass":"36bc0D02.", 'targetPswd':"gtu2017A", "projectName":projectName})
			else :
				print "Project Not Found!!!"
				

		elif action == "upload":
			projectPath = json_file['projectPath']
			forBuild = splitPathAndReturnFilename(projectPath)
			board = trello.getBoardByName(projectName)
			if not (board != None ):
				trello.createBoard()
			boardList= trello.boardList()
			board = trello.getBoardByName(projectName)
			lists = board.all_lists()
			toDo = lists[0]
			trello.createCard(board.id, toDo.id,forBuild)
			path = os.getcwd()
			os.popen('git clone https://github.com/canerkarakas/GtuDevOps.git')
			os.popen('mkdir '+path+'/'+"GtuDevOps/"+projectName)
			os.popen('touch '+path+'/'+"GtuDevOps/"+projectName+"/"+projectName+".txt")
			os.popen('git -C '+path+'/'+"GtuDevOps"+' remote set-url origin https://'+"canerkarakas"+':'+"36bc0D02."+'@github.com/'+"canerkarakas"+'/GtuDevOps.git')
			os.popen('git -C '+path+'/'+"GtuDevOps add "+projectName)
			os.popen('git -C '+path+'/GtuDevOps/'+projectName+' commit -m "first commit"')
			os.popen('git -C '+path+'/'+"GtuDevOps"+' push -u origin master')
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "repository_creation",'origin':"2",'destination':"6",'operation':"repository_creation", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps/tree/master/"+projectName,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName, 'forBuild':forBuild})
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "upload",'origin':"2",'destination':"6",'operation':"commit", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps",'repository_path':path+"/GtuDevOps/"+projectName,'project_path':projectPath, 'project_name': projectName, 'forBuild':forBuild})

		elif action == "newTask": 
			projectDescription = json_file['projectDescription']
			board = trello.getBoardByName(projectName)
			if not (board != None) :
				print "Project not found"
			else :
				'''path = os.getcwd()
				os.popen('git clone https://github.com/canerkarakas/GtuDevOps.git')'''
				boardList= trello.boardList()
				board = trello.getBoard(boardList[0].id)
				lists = board.all_lists()
				toDo = lists[0]
				trello.createCard(board.id,toDo.id,projectDescription)

		elif action == "uploadsql":
			projectPath = json_file['projectPath']
			forBuild = splitPathAndReturnFilename(projectPath)
			board = trello.getBoardByName(projectName+"SQL")
			if not (board != None):
				trello.createBoardForSQL(projectName+"SQL")
			board = trello.getBoardByName(projectName+"SQL")
			lists = board.all_lists()
			toDo = lists[0]
			trello.createCard(board.id,toDo.id,forBuild)
			moveAllCardToDOING(trello,projectName+"SQL")
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "upload",'origin':"2",'destination':"8",'op':"version", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps",'project_path':projectPath, 'project_name': projectName})
			
	elif origin == "6":
		description = json_file['description']
		github_login = json_file['github_login']
		github_password = json_file['github_password']
		repository_path = json_file['repository_path']
		repository_url = json_file['repository_url']
		project_name = repository_path.split("/")[-1]
		repository_url = "https://github.com/canerkarakas/GtuDevOps.git"
		forBuild = json_file['forBuild']
		operation = json_file['operation']
		moveAllCardToBUILD(trello,project_name)
		requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': description,'origin':"2",'destination':"1",'operation':operation, 'github_login': github_login,
            'github_password': github_password, 'repository_url': repository_url, 'project_name':project_name, 'object_type':"temp", 'project_path':repository_path, 'forBuild':forBuild})

	
	elif origin == "7":
		testresult = json_file['testresult']
		project_name= json_file['project_name']
		if testresult == "success":
			moveAllCardToDEPLOY(trello,project_name)
		else :
			repository_url = json_file['repoURL']
			path = os.getcwd()
			board = trello.getBoardByName(project_name)
			lists = board.all_lists()
			test = lists[3]
			trello.createCard(board.id,test.id,"FAIL")
			forBuild = json_file['forBuild']
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "revert",'origin':"2",'destination':"6",'operation':"revert", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': repository_url,'repository_path':path+"/GtuDevOps/"+project_name, 'project_name': project_name, 'forBuild':forBuild})

	elif origin == "8":
		result = json_file['result']
		project_name= json_file['project_name']
		moveAllCardToSQL(trello,project_name+"SQL")
		board = trello.getBoardByName(project_name+"SQL")
		lists = board.all_lists()
		sql = lists[2]
		trello.createCard(board.id,sql.id,result)

main_function(json_file)