public class SumTwoNum {
    public static int sumTwoNum(int a, int b){
        return a + b;
    }
}
