import java.util.Scanner;

public class SumTwoNum {
    public static int sumTwoNum(int a, int b){
        return a + b;
    }

    public static void main(String [] args){
    	Scanner myObj = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("Enter 1st Number");

	    String first = myObj.nextLine();  // Read user input

	    System.out.println("Enter 2nd Number");
	       String second = myObj.nextLine();

	    System.out.println("Sum : " + (sumTwoNum(Integer.parseInt(first),Integer.parseInt(second))));  // Output user input
    }
}
