from __future__ import absolute_import
import os
import json
import requests
from base64 import b64decode, b64encode
from io import open
import time

t_path = './temps/'
os.popen('mkdir '+ 'temps')
v_path = './versions/'
os.popen('mkdir '+ 'versions')

def send_to_plan(obj, status):
	"""
	@param obj: json object.
	@param status: true when pass, false when reject.
	"""
	pass

def save_file(path, cont):
	ff = open(path, 'w')
	ff.write(cont)
	ff.close()

def get_file(path):
	ff = open(path, 'r')
	cont = ff.read()
	ff.close()
	return cont

def version_file(filename, project_path,project_name, id, password):
	os.popen('cp ' + t_path + '/' + filename + ' ' + v_path + '/' + filename)
	os.popen('git -C ' + v_path + ' add ' + filename)
	os.popen('git -C ' + v_path + ' commit -m "' + filename + '"')
	path = os.getcwd()
	os.popen('git clone https://github.com/' + id + '/GtuDevOps.git')
	time.sleep(1)
	os.popen('mkdir '+ path + '/GtuDevOps/' + project_name)
	time.sleep(1)
	os.popen('cp -i '+ project_path + " " + path + '/' + "GtuDevOps/"  + project_name)
	time.sleep(1)
	os.popen('git -C '+path+'/'+"GtuDevOps"+' remote set-url origin https://'+id+':'+password+'@github.com/'+id+'/GtuDevOps.git')
	os.popen('git -C '+path+'/'+"GtuDevOps/"+project_name+" pull")
	time.sleep(1)
	os.popen('git -C '+path+'/'+"GtuDevOps add "+project_name)
	time.sleep(1)
	os.popen('git -C '+path+'/GtuDevOps/'+project_name+' commit -m "second commit"')
	time.sleep(1)
	os.popen('git -C '+path+'/'+"GtuDevOps"+' push -u origin master')
	time.sleep(1)
	os.popen('rm -f ' + t_path + '/' + filename)
	os.popen('rm -rf '+ path + '/' + "GtuDevOps")

def main(json_str):
	obj = json.loads(json_str)
	obj['destination'] = obj['origin']
	# get_script operasyonu iptal, README'yi kontrol edin.
	# kullanilmayacak ama kalsin.
	if 'get_script' == obj['op']: 
		is_exists = os.path.exists(v_path+obj['name'])
		if is_exists:
			decoded = get_file(v_path+obj['name'])
			obj['file'] = b64encode(str(decoded).encode('utf-8')).decode('utf-8')
			obj['op'] = '?' #TODO: OPERATE
		else:
			#TODO: script yok hata gonder OPERATE
			print 'Error, olmayan script istendi.'


	elif 'version' == obj['op']:
		#decoded = b64decode(obj['file']).decode('utf-8')
		# TODO: file_path ne olmali su an bilmiyorum.
		# ornek jsonda project_path var bizde ise name var
		# ikisinin birlesimi olarak yazdim.
		obj['name'] = obj['project_path'].split('/')[-1]
		file_path = obj['project_path']
		decoded = get_file(file_path)
		save_file(t_path+obj['name'], decoded)
		is_exists = os.path.exists(v_path+obj['name'])
		if is_exists:
			obj['destination'] = '9'
			decoded = get_file(t_path+obj['name'])
			obj['new'] = b64encode(str(decoded).encode('utf-8')).decode('utf-8')
			decoded = get_file(v_path+obj['name'])
			obj['old'] = b64encode(str(decoded).encode('utf-8')).decode('utf-8')
			obj['reminder'] = obj['origin']
		else:
			version_file(obj['name'], obj['project_path'], obj['project_name'], obj['github_login'], obj['github_password'])
			obj['result'] = True
	elif 'check' == obj['op']:
		obj['destination'] = obj['reminder']
		if obj['result']:
			version_file(obj['name'], obj['project_path'], obj['project_name'], obj['github_login'], obj['github_password'])
			obj['result'] = True
			# TODO: sql alma ve gonderme
			# {"origin": 8, "destination": 2, "name": "b", "result": true}
		else:
			print 'Error, versiyonlanamadi'
			obj['result'] = False
	obj['origin'] = '8'
	del obj['op']
	body = json.dumps(obj)
	requests.post("http://localhost:8081/", json=obj)

main(json_str)
