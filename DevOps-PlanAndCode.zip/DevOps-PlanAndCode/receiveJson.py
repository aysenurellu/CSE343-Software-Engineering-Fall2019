import json
import requests
import os
import trelloAPI

json_file = '{  "$schema":"http://json-schema.org/draft-04/schema#", "projectPath": "/home/bilmuhlab/Desktop/Group9-SQLConstraintChecker/difference1-test.sql","title": "Code versioning request","description":"Operation can be repository_creation,commit,merge,push,revert,pull",	    "destination": "6","projectName":"GtuDevOps2",	    "origin": "4",	    "operation":"upload","action":"newTask",   "github_login": "canerkarakas",    "github_password": "36bc0D02.",	    "repository_url": "https://github.com/canerkarakas/GtuDevOps"}'

#!/usr/bin/env python
# -*- coding: utf-8 -*- 
#from post.receive import planCodeAPI

def splitPathAndReturnFilename(path):
        return path.split("/")[-1]

def main_function(json_file):
	json_file = json.loads(json_file)
	origin = json_file['origin']
	'''user_id = json_file['github_login']
	user_pass = json_file['github_password']'''
	'''repository_url = json_file['repository_url']
	repository_url = repository_url.split("/")[3]'''
	'''trello_api = json_file['trello_api']
	trello_token = json_file['trello_token']'''

	'''destination'''
	
	"""
	print("LOGIN:\n" + user_id + user_pass + "\n" + repository_url+"\n"+trello_api+"\n"+trello_token)
	pc=planCodeAPI(user_id, user_pass, repository_url)
	#print("SELECTING PROJECT: " + project_name)
	"""
	trello = trelloAPI.trello(apiKey="88b6dfc53416a80d41bb516cb628df38",TOKEN="fd6bfab04572f641420ef120652d1adad1037f8189157dc7e1e6649244284ae1")


	if origin == "1":
		buildresult = json_file['buildresult']
		if buildresult == "success":
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			pass
		else :
			project_name = json_file['project_name']
			repository_url = json_file['repository_url']
			#showTrello
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "revert",'origin':"2",'destination':"6",'operation':"revert", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': repository_url,'repository_path':path+"/GtuDevOps/"+project_name, 'project_name': project_name})
	
	elif origin == "3":
		status = json_file['status']
		if status == "success":
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			pass
		else :
			projectName = json_file['projectName']
			repository_url = json_file['repoUrl']
			path = os.getcwd()
			os.popen('git clone '+repository_url)
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "revert",'origin':"2",'destination':"6",'operation':"revert", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': repository_url,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName})
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			pass
	
	elif origin == "4":
		action = json_file['action']
		if  action == "assignment":
			projectName = json_file['projectName']
			path = os.getcwd()
			os.popen('git clone https://github.com/canerkarakas/GtuDevOps.git')
			os.popen('mkdir '+path+'/'+"GtuDevOps/"+projectName)
			os.popen('touch '+path+'/'+"GtuDevOps/"+projectName+"/"+projectName+".txt")
			os.popen('git -C '+path+'/'+"GtuDevOps"+' remote set-url origin https://'+"canerkarakas"+':'+"36bc0D02."+'@github.com/'+"canerkarakas"+'/GtuDevOps.git')
			os.popen('git -C '+path+'/'+"GtuDevOps add "+projectName)
			os.popen('git -C '+path+'/GtuDevOps/'+projectName+' commit -m "first commit"')
			os.popen('git -C '+path+'/'+"GtuDevOps"+' push -f -u origin master')
			trello.createBoard(projectName)
			boardList= trello.boardList()
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "repository_creation",'origin':"2",'destination':"6",'operation':"repository_creation", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps/tree/master/"+projectName,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName})
            		#requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "repository_creation",'origin':"2",'destination':"6",'operation':"commit", 'github_login': "canerkarakas",
            #'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps/tree/master/"+projectName,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName})

		elif action == "undeploy":
			projectName = json_file['projectName']
			deployment = "undeploy"
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			requests.post("http://localhost:8081/", data = {'origin':"2",'destination':"3","deployment":"undeploy",'repoUrl': "https://github.com/canerkarakas/GtuDevOps.git","git_id":"canerkarakas","git_pass":"36bc0D02.", 'targetPswd':"gtu2017A", "projectName":projectName})

		elif action == "upload":
			projectName = json_file['projectName']
			trello.createBoard(projectName)
			boardList= trello.boardList()
			board = trello.getBoard(boardList[0].id)
			lists = board.all_lists()
			#trello.createCard(boardList[0].id,lists[0].id,"ihsan")
			'''cards = lists[0].list_cards()
			print boardList[0].id
			print lists[0].id
			print cards[0].name'''
			#print trello.getList(board.id ,boardList[0].id)
			toDo = lists[0]
			doing = lists[1]
			projectPath = json_file['projectPath']
			forBuild = splitPathAndReturnFilename(projectPath)
			trello.createCard(boardList[0].id,toDo.id,projectName)
			trello.createCard(boardList[0].id,doing.id,forBuild)
			projectName = json_file['projectName']
			'''path = os.getcwd()
			os.popen('git clone https://github.com/canerkarakas/GtuDevOps.git')
			os.popen('mkdir '+path+'/'+"GtuDevOps/"+projectName)
			os.popen('touch '+path+'/'+"GtuDevOps/"+projectName+"/"+projectName+".txt")
			os.popen('git -C '+path+'/'+"GtuDevOps"+' remote set-url origin https://'+"canerkarakas"+':'+"36bc0D02."+'@github.com/'+"canerkarakas"+'/GtuDevOps.git')
			os.popen('git -C '+path+'/'+"GtuDevOps add "+projectName)
			os.popen('git -C '+path+'/GtuDevOps/'+projectName+' commit -m "first commit"')
			os.popen('git -C '+path+'/'+"GtuDevOps"+' push -u origin master')

			forBuild = splitPathAndReturnFilename(projectPath)
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "repository_creation",'origin':"2",'destination':"6",'operation':"repository_creation", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps/tree/master/"+projectName,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName, 'forBuild':forBuild})
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "upload",'origin':"2",'destination':"6",'operation':"commit", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps",'repository_path':path+"/GtuDevOps/"+projectName,'project_path':projectPath, 'project_name': projectName, 'forBuild':forBuild})'''

		elif action == "newTask": 
			#projectDescription = json_file['ProjectDescription']
			projectName = json_file['projectName']
			'''path = os.getcwd()
			os.popen('git clone https://github.com/canerkarakas/GtuDevOps.git')'''
			boardList= trello.boardList()
			board = trello.getBoard(boardList[0].id)
			lists = board.all_lists()
			toDo = lists[0]
			trello.createCard(boardList[0].id,toDo.id,projectName)

		elif action == "uploadsql":
			projectPath = json_file['projectPath']
			projectName = json_file['projectName']
			forBuild = splitPathAndReturnFilename(projectPath)
			trello.createBoard(projectName)
			boardList= trello.boardList()
			print trello.getBoard()
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "upload",'origin':"2",'destination':"8",'op':"version", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': "https://github.com/canerkarakas/GtuDevOps",'project_path':projectPath, 'project_name': projectName})
			
	elif origin == "6":
		description = json_file['description']
		github_login = json_file['github_login']
		github_password = json_file['github_password']
		repository_path = json_file['repository_path']
		repository_url = json_file['repository_url']
		project_name = repository_path.split("/")[-1]
		repository_url = "https://github.com/canerkarakas/GtuDevOps.git"
		forBuild = json_file['forBuild']
		operation = json_file['operation']
		#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
		#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
		requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': description,'origin':"2",'destination':"1",'operation':operation, 'github_login': github_login,
            'github_password': github_password, 'repository_url': repository_url, 'project_name':project_name, 'object_type':"temp", 'project_path':repository_path, 'forBuild':forBuild})

	
	elif origin == "7":
		testresult = json_file['testresult']
		if testresult == "success":
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			pass
		else :
			repository_url = json_file['repoURL']
			project_name= json_file['project_name']
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello#show trello
			forBuild = json_file['forBuild']
			requests.post("http://localhost:8081/", data = {'title': "Plan request",'description': "revert",'origin':"2",'destination':"6",'operation':"revert", 'github_login': "canerkarakas",
            'github_password': "36bc0D02.", 'repository_url': repository_url,'repository_path':path+"/GtuDevOps/"+projectName, 'project_name': projectName, 'forBuild':forBuild})



	"""if status=="TRUE":
		print("TRUE")"""

			

		#self.client.list_boards()
		#print(trello.client.list_boards())
		#blist = trello.client.list_boards()
		#print(blist[0].name)


		
	
"""
	pc.chooseProject(project_name)
	if method_name=="build":
		if status == "TRUE":
			pc.moveAllCardToTEST()
		else:
			pc.moveAllCardToDOING()
			
	elif method_name=="test":
		if status == "TRUE":
			pc.moveAllCardToDEPLOY()
		else:
			pc.moveAllCardToDOING()
	
	elif method_name=="deploy":
		if status == "FALSE":
			pc.moveAllCardToDOING() """
	


main_function(json_file)