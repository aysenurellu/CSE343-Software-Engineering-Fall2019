########## IMPORT AREA #########



import trelloAPI


############# MAIN AREA ########



#github = githubapi.github()
#github.main()




def mainTrello():

    trello = trelloAPI.trello(apiKey="88b6dfc53416a80d41bb516cb628df38",TOKEN="fd6bfab04572f641420ef120652d1adad1037f8189157dc7e1e6649244284ae1")
    
    
    # Trello Projects
    boardList= trello.boardList()
    print(  boardList )
   # trello.getBoardByName()
    # Choose one of projects For Example last one
    """board = trello.getBoard(boardList[0].id)
    print(board.name)
    
    # list list of the board on the screen
    listBoard=board.get_lists(None)
    print(listBoard)
    
    toDo=listBoard[0]
    coding=listBoard[1]
    #build=listBoard[2]
    #test=listBoard[3]
    #deploy=listBoard[4]
    
    
    # cards of List
    print(toDo.list_cards())
    print(coding.list_cards())
    
    
    #move a card
    #cardID=toDo.list_cards()[0].id
    #trello.moveCard(cardID,coding.id)
    
    
    #print(trello.createBoard("bordAPI"))
    #trello.printTrello()
    #trello.closeBoardName("bordAPI")
    
    """


    '''organizationID = trello.createOrganization("apiTestTeam2")

    print(organizationID)


    print(trello.addOrganizationMember(organizationID,"aykocayko@gmail.com","admin"))
    print(trello.addOrganizationMember(organizationID,"my_kurt@hotmail.com","admin"))
    print(trello.getOrganization(organizationID).get_members())'''


    #createdBoard=trello.createBoard("TestBoard")
    #print(createdBoard)
    #trello.printTrello()
    #trello.closeBoardName("bordAPI")


    #organizationMembers = trello.getOrganization(organizationID).get_members()

    #print(organizationMembers.pop(-1).username)
   
     #   createdBoard.add_member(mem)



    #trello.closeBoard(createdBoard.id)

    #trello.removeOrganization(organizationID)

mainTrello()