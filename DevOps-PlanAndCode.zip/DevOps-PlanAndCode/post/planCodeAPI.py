from .Trello import Trello

import json
import requests

class planCodeAPI:
    def __init__(self, trelloApiKey="f76350738450d09229b56392d99b2a2c",trelloTOKEN="e33437ebf7ea4f97b74f208e830a161e21ce99c7a492d417f6e0dc3bed7655b5"):
        self.trello = Trello(trelloApiKey,trelloTOKEN)

    def createProject(self,projectName):
            self.trello.createBoard(boardName=projectName)

    def showProjects(self):
        return self.github.show_projects()

    def chooseProject(self,projectName):
        self.trello.selectBoard(projectName)

    def deleteProject(self):
        self.trello.closeBoard()


    def showCommits(self):
        return self.github.show_project()


    # show board, lists, cards
    def showBoards(self):
        return self.trello.showBoards()

    def getTrelloToDoList(self): # id name
        return self.trello.getToDoList()


    def getTrelloDoingList(self):
        return self.trello.getDoingList()

    def getTrelloBuildList(self):
        return self.trello.getBuildList()

    def getTrelloTestList(self):
        return self.trello.getTestList()
    def getTrelloDeployList(self):
        return self.trello.getDeployList()



    def getTrelloToDoCards(self):
        return self.trello.getToDoCards()

    def getTrelloToDoCardsString(self):
        str=""
        for x in self.getTrelloToDoCards():
            str+=x.id+" "+x.name+"\n"
        return str



    def getTrelloDoingCards(self):
        return self.trello.getDoingCards()

    def getTrelloDoingCardsString(self):
        str=""
        for x in self.getTrelloDoingCards():
            str+=x.id+" "+x.name+"\n"
        return str

    def getTrelloBuildCards(self):
        return self.trello.getBuildCards()

    def getTrelloBuildCardsString(self):
        str=""
        for x in self.getTrelloBuildCards():
            str+=x.id+" "+x.name+"\n"
        return str

    def getTrelloTestCards(self):
        return self.trello.getTestCards()

    def getTrelloTestCardsString(self):
        str=""
        for x in self.getTrelloTestCards():
            str+=x.id+" "+x.name+"\n"
        return str

    def getTrelloDeployCards(self):
        return self.trello.getDeployCards()

    def getTrelloDeployCardsString(self):
        str=""
        for x in self.getTrelloDeployCards():
            str+=x.id+" "+x.name+"\n"
        return str

    def moveCard(self,cardID,destListID):
        self.trello.moveCard3(cardID,destListID)

    def deleteCard(self,cardID):
        self.trello.trelloAPI.removeCard(cardID)

    def createCard(self,listID,cardName):
        self.trello.createCard(self.trello.board.id,listID,cardName)

    def moveAllCardToList(self,listID):
        for x in self.trello.board.all_cards():
            self.moveCard(x.id,listID)

    def moveAllCardToDOING(self):
        self.moveAllCardToList(self.getTrelloDoingList().id)

    def moveAllCardToTEST(self):
        self.moveAllCardToList(self.getTrelloTestList().id)

    def moveAllCardToDEPLOY(self):
        self.moveAllCardToList(self.getTrelloDeployList().id)

    def deleteCard(self,cardID):

        self.trello.deleteCard(cardID)

    def addCommendToCard(self,cardID,commendText):
        self.trello.addCommendToCard(cardID,commendText)